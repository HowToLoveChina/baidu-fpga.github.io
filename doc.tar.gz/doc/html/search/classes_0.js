var searchData=
[
  ['polariscontext',['PolarisContext',['../struct_polaris_context.html',1,'']]]
];
