var searchData=
[
  ['polaris_5factivation',['polaris_activation',['../api_8h.html#afdbc6616671772498819f3786ecdacc4',1,'api.h']]],
  ['polaris_5fbatch_5fmemcpy',['polaris_batch_memcpy',['../api_8h.html#a90d291284c6db77c07744f3b37890f3f',1,'api.h']]],
  ['polaris_5fcreate_5fcontext',['polaris_create_context',['../api_8h.html#ace2c83418f860b7bac62d3c3924382c6',1,'api.h']]],
  ['polaris_5fdeactivation',['polaris_deactivation',['../api_8h.html#aee2814142e25eb51d50e17da034cc0dc',1,'api.h']]],
  ['polaris_5fdestroy_5fcontext',['polaris_destroy_context',['../api_8h.html#a4a1901427bd611138769cba7df5da14c',1,'api.h']]],
  ['polaris_5feltwise',['polaris_eltwise',['../api_8h.html#a6deac46ed2aef1b80d2f3d96fc5eb8f9',1,'api.h']]],
  ['polaris_5ffree',['polaris_free',['../api_8h.html#addfd5b9038cd18afd7ab659cf375cf03',1,'api.h']]],
  ['polaris_5ffree_5fhost',['polaris_free_host',['../api_8h.html#a99c4286b974f44762b9e21bd693b778a',1,'api.h']]],
  ['polaris_5fgemm',['polaris_gemm',['../api_8h.html#af49f83d3a76ee36b30b42f022d0cd70d',1,'api.h']]],
  ['polaris_5fget_5fdevices',['polaris_get_devices',['../api_8h.html#ac3fb3fbd848210eff75f200bdf87b882',1,'polaris_get_devices(int *devs, int devs_len):&#160;api.h'],['../api_8h.html#aef8dfbdbd2ebede8feff4dc1f3705558',1,'polaris_get_devices(const char *firmware_name, int *devs, int devs_len):&#160;api.h']]],
  ['polaris_5fget_5fdriver_5fversion',['polaris_get_driver_version',['../api_8h.html#ac714bca03dde561ee992bf95b3faa36f',1,'api.h']]],
  ['polaris_5fget_5fversion',['polaris_get_version',['../api_8h.html#a9b23870899e7358d2dc4c7992cbc8b27',1,'api.h']]],
  ['polaris_5fmalloc',['polaris_malloc',['../api_8h.html#aa3049359805ca17de4af090e4879321f',1,'api.h']]],
  ['polaris_5fmalloc_5fhost',['polaris_malloc_host',['../api_8h.html#afa9640526a5a536cc07d78cf31363143',1,'api.h']]],
  ['polaris_5fmemcpy',['polaris_memcpy',['../api_8h.html#a40d6924520aa7ace912048842126bf5e',1,'api.h']]],
  ['polaris_5fmemset',['polaris_memset',['../api_8h.html#abca228e59e4c5fa783d83edc06c87806',1,'api.h']]],
  ['polaris_5fread_5fregister',['polaris_read_register',['../api_8h.html#a5368fecd27ed8485a6da055f50b3aba5',1,'api.h']]],
  ['polaris_5ftranspose',['polaris_transpose',['../api_8h.html#ad287fd8bf298cb14d0f165d938a35cb0',1,'api.h']]],
  ['polaris_5fwrite_5fregister',['polaris_write_register',['../api_8h.html#af9f795b7b458b246eefeb1e970ec19ae',1,'api.h']]]
];
