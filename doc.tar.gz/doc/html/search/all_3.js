var searchData=
[
  ['max_5fdevice_5fcount',['MAX_DEVICE_COUNT',['../api_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba65a3b7ef8dfe5e8d64b1bc5a379a2d5d',1,'api.h']]],
  ['max_5ffirmware_5fname_5flength',['MAX_FIRMWARE_NAME_LENGTH',['../api_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba32faf76fa74eb7edc07f434719c18152',1,'api.h']]],
  ['max_5fversion_5fstring_5flength',['MAX_VERSION_STRING_LENGTH',['../api_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba5a9dbd22e7a7bb77a44d38637e367178',1,'api.h']]]
];
