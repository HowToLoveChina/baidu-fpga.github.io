var searchData=
[
  ['polaris_20manual',['Polaris Manual',['../index.html',1,'']]]
];
